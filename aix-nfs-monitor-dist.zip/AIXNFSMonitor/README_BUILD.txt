# This is a placeholder - replace with actual compiled JAR
# To build the actual JAR:
# 1. Add AppDynamics SDK to Maven repository  
# 2. Run: mvn clean install in nfs-monitor-extension/
# 3. The JAR will be in target/aix-nfs-monitor.jar
